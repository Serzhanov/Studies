#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "listes.h"
#include <malloc.h>
/* fichier à compléter au besoin */


void vider_liste(liste_t *L){
  cellule_t *cel;
  cellule_t *pred;
  cel=L->tete;
  pred=cel;
  while(pred!=NULL){
    pred=cel;
    free(pred);
    cel=cel->suivant;
  }

}

void init_liste_vide(liste_t* L) {
    
    /*if(L->tete!=NULL){
      vider_liste(L);
    }
    else{
      printf("Liste est vide\n");
    }
    */
    L->tete=NULL;
}


int ajouter_tete(liste_t* L, string c) { /* retourne 0 si OK, 1 sinon  */
    /* a completer */
    cellule_t *pred;
    pred=L->tete;
    cellule_t *cel=malloc(sizeof(cellule_t));
    cel->val=c;
    printf("%s\n",c);
    cel->suivant=L->tete;
    L->tete=cel;
    if(cel==pred){
      return 0;
    
    }
    else {
      return 1;}
    
}


void ajouter_suivant(liste_t *L,string c){
  cellule_t *cel=(cellule_t*)malloc(sizeof(cellule_t));
  cellule_t *pred;
  cellule_t *p;
  cel->val=c;
  pred=L->tete;
  if(pred==NULL){
    L->tete=cel;
  }
  else{
    p=L->tete;
    while(p->suivant!=NULL){
      p=p->suivant;
    }
    p->suivant=cel;
  }
}


void copyy(liste_t* L,liste_t *Q){
  cellule_t *cel;
  cel=L->tete;
  while(cel!=NULL){
    ajouter_suivant(Q,cel->val);
    cel=cel->suivant;
  }
}