#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>

#include "arbres.h"

noeud* nouveau_noeud(void)
{
    noeud *n = (noeud*)malloc(sizeof(noeud));
    assert (n!=NULL);
    n->valeur = NULL;
    n->gauche = NULL;
    n->droit  = NULL;
    return n;
}


/* buffer pour lire les caractères des espèces sous forme de "mots" (words) */
#define MAX_WORD_SIZE 255
char buffer[MAX_WORD_SIZE+1];

/* Variable globale qui contient le prochain caractère à traiter */
static char next_char = ' ';

/* Supprime tous les espaces, tabulations, retour à la ligne */
#define GLOB(f) \
    while(isspace(next_char)) { \
        next_char = fgetc(f);\
    }


/* Fonction récursive qui lit un sous-arbre */
/* Appelée une fois à la racine (debut du fichier), puis récursivement
 * pour chaque nœud interne rencontré. */
arbre lire_arbre (FILE *f)
{
    arbre racine;

    GLOB(f); /* lit dans next_char le premier caractère non vide */

    if (next_char == '/') {
        next_char = ' '; /* on ne garde pas '/' en mémoire */
        return NULL;
    }

    if (next_char == ')') {
        return NULL;
    }

    if (next_char != '(') {
        fprintf(stderr, "Error while reading binary tree : '(' or ')' expected at position %ld\n", ftell(f));
        exit (1);
    }

    /* On remplit le buffer tant qu'on lit des caractères alphanumériques */
    char *p = buffer; /* début du buffer */
    next_char = ' '; GLOB(f);

    do {
        *p = next_char;       /* sauvegarde du char courant */
        next_char = fgetc(f);
        p++;
        assert (p < buffer + MAX_WORD_SIZE);
    } while (! isspace (next_char) && next_char != '(' && next_char != ')');
    /* on arrète si le char suivant est un espace ou une parenthèse */
    *p='\0'; /* on ferme la chaîne de caractères dans le buffer */

    racine = nouveau_noeud();
    racine->valeur = strdup(buffer); /* dupliquer le mot lu */

    GLOB(f);

    if (next_char == ')') {
        next_char = ' '; /* on est sur une feuille, on prépare la lecture du prochain nœud */
    }
    else {
        racine->gauche = lire_arbre (f); /* appel récursif pour le fils gauche */
        racine->droit  = lire_arbre (f); /* idem pour le droit */

        GLOB(f); /* lit jusqu'au ')' fermant */

        if (next_char != ')') {
            fprintf(stderr, "Error while reading binary tree: ')' expected\n");
            exit(1);
        }
        next_char = ' '; /* on ne garde pas la parenthèse en mémoire */
    }
    return racine;
}


void aff_arbre(noeud *racine,FILE *f){//LA FOCTION QUI ECRIT L'ARBRE POUR GRAPHIZ
  if(racine->gauche==NULL && racine->droit==NULL){
    
    
  }
  else if  (racine->gauche!=NULL && racine->droit==NULL){
    fprintf(f,"%s %s %s\n",racine->valeur,"->",racine->gauche->valeur);
    aff_arbre(racine->gauche,f);
    }
  
  else if (racine->gauche==NULL && racine->droit!=NULL) {
    fprintf(f,"%s %s %s\n",racine->valeur,"->",racine->droit->valeur);
    aff_arbre(racine->droit,f);
  }
  
    
  else {
    fprintf(f,"%s %s %s\n",racine->valeur,"->",racine->gauche->valeur);
    fprintf(f,"%s %s %s\n",racine->valeur,"->",racine->droit->valeur);
    aff_arbre(racine->gauche,f);
    aff_arbre(racine->droit,f);
  }


}


int count_d(noeud *racine){

  if(racine==NULL){
    return 0;
  
  }
  else{
    return 1+count_d(racine->droit);
  }

}


int count_g(noeud *racine){
  if(racine==NULL){
    
    return 0;
  }
  else{
  
    return 1+count_g(racine->gauche);
  }
}

void compteur(noeud *racine,int *r,int *l){//LE COMPTEUR DE PROFONDEUR  DE GAUCHE ET DROIT
  *r=count_d(racine);
  *l=count_g(racine);
}

void affiche_arbre_90rot(noeud *racine,int space,int c_g,int c_d){//AFFICHAGE  UN ARBRE EN 90 DEGREE
  if(racine==NULL){
    return;
  }
  space+=(c_g+c_d);
  affiche_arbre_90rot(racine->droit,space,c_g,c_d);
  printf("\n");
  for(int i=(c_g+c_d);i<space;i++){
    printf(" ");
  }
  printf("%s\n",racine->valeur);
  affiche_arbre_90rot(racine->gauche,space,c_g,c_d);
}

void affiche_arbre (noeud *racine)//La fonction graphiz a afficher
{
    FILE *f;
    f=fopen("good.gv","w");
    fprintf(f,"%s\n","digraph arbre {");
    aff_arbre(racine,f);
    fprintf(f,"%s","}");
    fclose(f);
    system("dot -Tpng good.gv -o good.png");
    system("display good.png");
}


arbre cherche_val(arbre a,char* c){//LA FONCTION RENVOIT UN NEOUD QUI CONTIENT LA VALEUR C
  if(a==NULL){
    return NULL;
  }
  else{
    if(strcmp(a->valeur,c)==0){
      return a;
    }
    else{
      arbre new_a;
      new_a=cherche_val(a->gauche,c);
      if(new_a==NULL){
        new_a=cherche_val(a->droit,c);
      }
      return new_a;
    }
  }
  
}