#ifndef _QUEUE_H
#define _QUEUE_H
#include "arbres.h"
typedef struct queue queue_l;
/* Type de liste à compléter selon votre besoin. */

typedef char* string;

struct element_queue {
	arbre tree;
	struct element_queue* suivant;
};

typedef struct element_queue queue_t;

struct queue {
	queue_t *tete;
};

typedef struct queue queue_l;

/* cree une nouvelle liste, initialement vide */
void init_liste_vide_q(queue_l* Q);

/* Ajouter une nouvelle cellule contenant c
 * en tête de la liste L.
 * Si l'ajout est réussi, le résultat est 0,
 * et 1 sinon (échec de l'ajout)
 */
void ajouter_tete_q(queue_l *Q,arbre tree);

void printage_queue(queue_l *Q);

arbre defiler(queue_l *Q);


void enfiler(queue_l *Q,arbre tree);

void vider_liste_q(queue_l *Q);
#endif /* _QUEUE_H */

