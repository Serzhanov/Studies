#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "queue.h"
#include <malloc.h>

/* fichier à compQéter au besoin */


void vider_liste_q(queue_l *Q){
  queue_t *element;
  queue_t *pred;
  element=Q->tete;
  pred=element;
  while(pred!=NULL){
    pred=element;
    free(pred);
    element=element->suivant;
  }

}

void init_liste_vide_q(queue_l* Q) {
    
    /*if(Q->tete!=NULL){
      vider_liste_q(Q);
    }
    else{
      printf("file est vide\n");
    }
    */
    Q->tete=NULL;
}


/*void ajouter_tete_q(queue_l* Q, noeud n) {  retourne 0 si OK, 1 sinon  */
    /* a compQeter 
    queue_t *element=malloc(sizeof(queue_l));
    element->uzel=n;
    printf("%s\n",c);
    element->suivant=Q->tete;
    Q->tete=element;
    
}

*/

void enfiler(queue_l *Q,arbre tree2){
  queue_t *element=(queue_t*)malloc(sizeof(queue_t));
  element->suivant=NULL;
  element->tree=tree2;
  queue_t *p;
  p=Q->tete;
  if(p==NULL){
    Q->tete=element;
  }
  else{
    while(p->suivant!=NULL){
      p=p->suivant;
    }
    p->suivant=element;
  }
}


arbre defiler(queue_l *Q){
  arbre a=NULL;
  if(Q->tete!=NULL){
    if(Q->tete->suivant==NULL){
      queue_t *p2;
      p2=Q->tete;
      Q->tete=NULL;
      a=p2->tree;
      free(p2);
    }
    else{
      queue_t *delibre;
      queue_t *p;
      p=Q->tete->suivant;
      delibre=Q->tete;
      Q->tete=p;
      a=delibre->tree;
      free(delibre);
      }
    }
  else{
    printf("Queue is empty\n");
    return a;
  
  }
  return a;
}


void printage_queue(queue_l *Q){
  queue_t *p;
  p=Q->tete;
  while(p!=NULL){
    printf("%s\n",p->tree->valeur);
    p=p->suivant;
  }

}