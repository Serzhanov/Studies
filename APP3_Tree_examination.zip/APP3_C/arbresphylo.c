#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include "arbres.h"
#include "arbresphylo.h"
#include "listes.h"
#include "queue.h"

void analyse_arbre_rec(arbre racine, int* nb_esp, int* nb_carac)// compteur des especes et caracterestiques dans l'arbre
{
    if (racine == NULL)
    {
        *nb_esp = 0;
        *nb_carac = 0;
    }
    else
    {
        if (racine->gauche == NULL && racine->droit == NULL)
        {
            *nb_esp += 1;
        }
        else if (racine->droit == NULL && racine->gauche != NULL)
        {
            *nb_carac += 1;
            analyse_arbre_rec(racine->gauche, nb_esp, nb_carac);//O(h)
        }
        else if (racine->droit != NULL && racine->gauche == NULL)
        {
            *nb_carac += 1;
            analyse_arbre_rec(racine->droit, nb_esp, nb_carac);////O(h)
        }
        else if (racine->droit != NULL && racine->gauche != NULL)
        {
            *nb_carac += 1;
            analyse_arbre_rec(racine->gauche, nb_esp, nb_carac);//O(h)
            analyse_arbre_rec(racine->droit, nb_esp, nb_carac);//O(h)
        }
    }
}


void analyse_arbre(arbre racine, int* nb_esp, int* nb_carac)
{
    *nb_esp = 0;
    *nb_carac = 0;
    analyse_arbre_rec(racine, nb_esp, nb_carac);//O(h) au total
}





/* ACTE II */
/* Recherche l'espece dans l'arbre. Modifie la liste passée en paramètre pour y mettre les
 * caractéristiques. Retourne 0 si l'espèce a été retrouvée, 1 sinon.
 */
int rechercher_espece (arbre racine, char *espece, liste_t* seq)//recherche espece dans l'arbre la complexite :O(h)
{  
    if (racine==NULL){
      return 1;
    }
    else {
      if (racine->gauche==NULL && racine->droit==NULL){
        if (strcmp(racine->valeur,espece)==0){
          return 0;
        }
        else{
          return 1;
        }
      }
      else{
        int gauche=rechercher_espece(racine->gauche,espece,seq);
        int droit=rechercher_espece(racine->droit,espece,seq);
        if(droit==0 && gauche!=0){
          ajouter_tete(seq,racine->valeur);
          return 0;
        }
        else if(gauche==0 && droit!=0){
          return 0;
        }
        else{
          return 1;
        
        }
      
      }
  }
}
//ACTE3
//la fonction ajouter_espece_rec :
/*  
  On parcour arbre jusqu'a  on trouve un espece ,on cree un noeud pour le nouveau espece et on dit que sa valeur est egal a  valeur d'espece(argument)  et l'ancien espece devient  caracteristique et sa valeur egal a la valeur de la cellule et apres on dit
  
  la complexite O(h) car on fait parcour par arbre,mais pour ajouter une feuille a la fois ca nous cout O(1)
  
*/
arbre ajouter_espece_rec(arbre a, char* espece, cellule_t* seq, int* res) {
    if(seq != NULL)
    {
        if (a != NULL)
        {
            if (a->droit == NULL && a->gauche == NULL)
            {
                a->gauche = nouveau_noeud();
                a->gauche->valeur = a->valeur;
                a->valeur = seq->val;
                a->droit = ajouter_espece_rec(a->droit, espece, seq->suivant, res);
            } 
            else
            {
                if (strcmp(seq->val,a->valeur) == 0)
                {
                    a->droit = ajouter_espece_rec(a->droit, espece, seq->suivant, res);
                }
                else
                {
                    a->gauche = ajouter_espece_rec(a->gauche, espece, seq, res);
                }
            }
        }
        else
        {
            arbre a_new = nouveau_noeud();
            a_new->valeur = seq->val;
            a_new->droit = ajouter_espece_rec(a_new->droit, espece, seq->suivant, res);
            return a_new;
        }
    }
    else
    {
        if (a != NULL)
        {
            if (a->droit == NULL && a->gauche == NULL)
            {
                printf("Ne peut ajouter %s: possede les memes caracteres que %s\n",espece,a->valeur);
                *res = 1;
                return a;
            }
            else
            {
                a->gauche = ajouter_espece_rec(a->gauche, espece, seq, res);
            }
        }
        else
        {
            arbre a_new = nouveau_noeud();
            a_new->valeur = espece;
            *res = 0;
            return a_new;
        }
    }
    return a;
}


int ajouter_espece(arbre* a, char* espece, cellule_t* seq) {
    int res = 1;
    *a = ajouter_espece_rec(*a, espece, seq, &res);
    return res;
}

void afficher_par_niveau(arbre racine, FILE* fout){
  queue_l queue;
  init_liste_vide_q(&queue);
  afficher_par_niveau2(racine,fout,&queue);


}
// Acte3b

/*
 On fait parcour en largeur dans un arbre et on utilise la deuxieme boucle pour ecrire  dans le fichier le niveau de l'arbre sur la ligne
 La complexite:O(n)+(O(n)xO(n))+O(n)+O(n)=O(n^2)
*/
void afficher_par_niveau2 (arbre racine, FILE* fout,queue_l *queue) {
  if (racine!=NULL){
    arbre new_tree;
    enfiler(queue,racine);//O(n)
    int compteur_de_noeuds_dans_niveau=1;
    while(queue->tete!=NULL){//O(n)
      int niveau=0;
      int n=compteur_de_noeuds_dans_niveau;
      compteur_de_noeuds_dans_niveau=0;
      while (queue->tete!=NULL && niveau<n){//x n
        new_tree=defiler(queue);//O(1)
        if(new_tree->gauche!=NULL || new_tree->droit!=NULL){ 
          fprintf(fout,"%s ",new_tree->valeur);
          printf("valeur -> %s\n",new_tree->valeur);
          if(new_tree->gauche!=NULL){
            enfiler(queue,new_tree->gauche);//O(n)
            compteur_de_noeuds_dans_niveau++;
          }
          if(new_tree->droit!=NULL){
            enfiler(queue,new_tree->droit);//O(n)
            compteur_de_noeuds_dans_niveau++;
            }
        }
        niveau++;
      }
    fprintf(fout,"\n");
    }
  }
  printf ("<<<<< A faire: fonction afficher_par_niveau fichier " __FILE__ "\n >>>>>");
}


//Acte4


/*
Description d'algo:
On sait notre liste des especes ,alors on prend la premiere valeur de cette liste et la derniere ,apres on cherche leur caracterestique commun ca nous donne un sous arbre ,apres pour verifier si on a le droit a ajouter la caracterestique je ecrit tous les espece dans une autre liste,apres si ces deux listes sont egaux ,alors on a le droit d'ajouter la caracterestique sinon(Ne peut ajouter <caracteristique>: ne forme pas un sous-arbre).
 Apres on essaie d'ajouter des caracterestique ,mais il y avait un cas ou le sous_arbre a ete espece,alors si oui ,redefini notre arbre en ajoutant la caracterestique en racine,sinon on ajoute bien la caracterestique dans arbre

*/
int verification_liste(liste_t* to_verify, liste_t* given_liste){//la verification de deux listes si ils sont egaux ou non
  cellule_t* verif_parc = to_verify->tete;
  cellule_t* given_parc = given_liste->tete;
  while ((given_parc != NULL)&&(verif_parc !=NULL)){
    if (strcmp(given_parc->val ,verif_parc->val)!=0){
      return 1;
    }
    given_parc = given_parc->suivant;
    verif_parc = verif_parc->suivant;
  }
  return 0;
}

arbre sous_arbre_f(arbre a, arbre first, arbre last){//return sous-arbre (caracterestique commune) de deux especes first et last
  if (a == NULL){
    return a;
  }
  if (a==first || a==last){
    return a;
  }
  else{
    arbre l =sous_arbre_f(a->gauche, first,last);
    arbre r = sous_arbre_f(a->droit, first,last);
    if(l!=NULL && r!=NULL){
      return a;
    }
    else if(l!=NULL){
      return l;
    }
    else{
      return r;
    }
  }
} 

void delibre_a(arbre a){//liberation de l'arbre
  if(a!=NULL){
    delibre_a(a->gauche);
    delibre_a(a->droit);
    free(a);
  }



}
void finding_all_especes(arbre a, liste_t* especes){//on ecrit tous les especes dans la liste
  if (a!=NULL){
    if ((a->gauche == NULL)&&(a->droit == NULL)){
      ajouter_suivant(especes,a->valeur);
    }
    else{
      finding_all_especes(a->gauche,especes);
      finding_all_especes(a->droit,especes);
    }
  }
}

arbre ska(arbre a,arbre sous_arbre,char *carac){//verification si sous arbre est un espece
  if((sous_arbre->gauche==NULL && sous_arbre->droit==NULL)&&a->gauche==NULL){
        arbre nouveau=nouveau_noeud();
        nouveau->valeur=carac;
        nouveau->droit=a;
        nouveau->gauche=NULL;
        return nouveau;
    }
  return a;
}

arbre ajoute_carac(arbre a,arbre sous_arbre,char *carac){//on ajoute des caracterestiques
  if(a!=NULL){
    if(a!=sous_arbre){
      if(a->gauche==sous_arbre){
        arbre nouveau=nouveau_noeud();
        nouveau->valeur=carac;
        nouveau->droit=sous_arbre;
        a->gauche=nouveau;
        return a;
      }
      else if(a->droit==sous_arbre){
        arbre nouveau=nouveau_noeud();
        nouveau->valeur=carac;
        nouveau->droit=sous_arbre;
        a->droit=nouveau;
        return a;
      }
      else{
        a->gauche=ajoute_carac(a->gauche,sous_arbre,carac);
        a->droit=ajoute_carac(a->droit,sous_arbre,carac);
        return a;
      }
    }
    else{
      arbre nouveau=nouveau_noeud();
      nouveau->valeur=carac;
      nouveau->droit=a;
      nouveau->gauche=NULL;
      return nouveau;
    }
  }
  return a;
}


arbre ajouter_carac2(arbre a, char* carac,liste_t *seq){//la fonction principale qui nous donne un arbre ou a ete ajouter la caracterestique
  if(a==NULL){
    return a;
  }
  liste_t to_verif;
  init_liste_vide(&to_verif);

  arbre p=cherche_val(a,seq->tete->val);
  
  cellule_t *cel;
  cel=seq->tete;
  while(cel->suivant!=NULL){
    cel=cel->suivant;
  }
  arbre q=cherche_val(a,cel->val);
  arbre sous=sous_arbre_f(a,p,q);
  finding_all_especes(sous,&to_verif);
  if(verification_liste(&to_verif,seq)==1){
    printf("Ne peut ajouter %s:ne forme pas un sous-arbre\n",carac);
    return a;
  }
  arbre a2=ska(a,sous,carac);
  if(a!=a2){
    a=a2;
    delibre_a(a2);
  }
  else{
    a=ajoute_carac(a,sous,carac);
  }
  return a;
}

int ajouter_carac(arbre *a,arbre a2, char* carac,liste_t *seq){
  (*a)=a2;
  liste_t to_verif;
  init_liste_vide(&to_verif);
  finding_all_especes(a2,&to_verif);
  return 0;
}
