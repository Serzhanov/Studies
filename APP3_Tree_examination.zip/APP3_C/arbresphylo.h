#ifndef ARBRESPHYLO_H
#define ARBRESPHYLO_H

#include "listes.h"
#include "queue.h"

/* Analyse un arbre: doit mettre à jour le nombre d'espèces et de 
 * caractéristiques.
 */
void analyse_arbre (arbre racine, int* nb_esp, int* nb_carac);

/* Recherche une espèce dans l'arbre et remplit seq avec la séquence de ses 
 * caractéristiques.
 *
 * Doit retourner 0 si l'espèce a été retrouvée, 1 sinon.
 */
int rechercher_espece (arbre racine, char *espece, liste_t* seq);


int ajouter_espece(arbre* a, char* espece, cellule_t* seq);

arbre ajouter_espece_rec(arbre a, char* espece, cellule_t* seq, int* res);

int ajouter_carac(arbre *a,arbre a2, char* carac, liste_t *seq);

arbre ajouter_carac2(arbre a, char* carac,liste_t *seq);


void afficher_par_niveau (arbre racine, FILE* fout);

void finding_all_especes(arbre a, liste_t* especes);

void afficher_par_niveau2 (arbre racine, FILE* fout,queue_l *queue);

arbre sous_arbre_f(arbre a, arbre first, arbre last);

int verification_liste(liste_t* to_verify, liste_t* given_liste);

#endif
